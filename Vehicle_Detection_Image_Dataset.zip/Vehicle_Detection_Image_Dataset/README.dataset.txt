# Vehicle_Detection_YOLOv8 > 2023-12-03 
https://universe.roboflow.com/farzad/vehicle_detection_yolov8

License: CC BY 4.0

