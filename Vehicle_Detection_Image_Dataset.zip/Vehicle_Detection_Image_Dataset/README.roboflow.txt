
Vehicle_Detection_YOLOv8 - v3 2023-12-03 
==============================

This dataset was exported via roboflow.com on December 3, 2023 

The dataset includes 626 images.
Vehicle are annotated in YOLOv8 format.

The following pre-processing was applied to each image:
* Resize to 640x640 (Stretch)

The following augmentation was applied to create 2 versions of each source image:
* 50% probability of horizontal flip


